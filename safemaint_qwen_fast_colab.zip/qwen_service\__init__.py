"""SafeMaint Qwen inference service."""
